import { useState } from 'react';
import axios from 'axios';

export function Chat() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [loading, setLoading] = useState(false);

  const askQuestion = async () => {
    if (!question.trim()) return;
    setLoading(true);
    setAnswer('');

    try {
      const res = await axios.post('http://localhost:3001/api/chat', {
        messages: [{ role: 'user', content: question }],
      });

      setAnswer(res.data.reply);
    } catch (err) {
      setAnswer('Something went wrong. Please try again.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{ maxWidth: '600px', margin: '50px auto', padding: '1rem' }}>
      <h2>Ask the Assistant</h2>
      <textarea
        value={question}
        onChange={(e) => setQuestion(e.target.value)}
        placeholder="Type your question here..."
        rows={4}
        style={{ width: '100%', padding: '10px', fontSize: '16px' }}
      />

      <button
        onClick={askQuestion}
        disabled={loading}
        style={{
          marginTop: '10px',
          padding: '10px 20px',
          fontSize: '16px',
        }}
      >
        {loading ? 'Asking...' : 'Send'}
      </button>

      {answer && (
        <div
          style={{
            marginTop: '20px',
            padding: '15px',
            background: '#f4f4f4',
            borderRadius: '8px',
          }}
        >
          <strong>Assistant:</strong>
          <p>{answer}</p>
        </div>
      )}
    </div>
  );
}
