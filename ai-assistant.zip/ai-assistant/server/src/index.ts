import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import axios from 'axios';

const app = express();
app.use(cors());
app.use(express.json());

const apiKey = process.env.OPENROUTER_API_KEY!;
const apiUrl = 'https://openrouter.ai/api/v1/chat/completions';

app.post('/api/chat', async (req, res) => {
  try {
    const { messages, location } = req.body;

    const locationPrompt = location
      ? ` The user is at latitude ${location.lat} and longitude ${location.lon}.`
      : '';

    const fullMessages = [
      {
        role: 'system',
        content: 'You are a helpful assistant.' + locationPrompt,
      },
      ...messages,
    ];

   const response = await axios.post(
  apiUrl,
  {
    model: 'mistralai/mistral-7b-instruct', // ✅ Confirmed working model
    messages: fullMessages,
  },
  {
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'HTTP-Referer': 'http://localhost:5173',
      'X-Title': 'Aurora Assistant',
    },
  }
);


    res.json({ reply: response.data.choices[0].message.content });
  } catch (err: any) {
    console.error('❌ Error in /api/chat:', err.response?.data || err.message);
    res.status(500).json({ error: 'Something went wrong.' });
  }
});

app.listen(3001, () => {
  console.log('✅ Server running at http://localhost:3001');
});
